# Aniket's Next.js portfolio

Built with Next.js App Router, React, Lucide icons, and custom responsive CSS.

Run `npm ci` followed by `npm run dev`, then open http://127.0.0.1:4174.
Run `npm run build` and upload the contents of `out/` to a static host, or deploy the source as a Next.js project.

## Editing
- app/page.js: sections and React interactions.
- app/globals.css: styling and responsive layout.
- lib/projects.js: project content. Add real website URLs to the url fields.
- public/Aniket_Resume.pdf: downloadable resume.

Project illustrations are interface concepts, not actual app screenshots. Resume facts were preserved. Review current employment dates before publishing. No project URLs were provided.

The old HTML site remains in dist/ for reference. The current build is out/. Contact links open an email client. Google Fonts have local fallbacks.

Production build and browser checks for tabs, filters, and project dialogs passed. Hosting remains local because publishing permission was previously declined.

Public screenshot repositories are in lib/websites.js. MERN and English Communication URLs responded successfully on 2026-10-06. Java homepage URLs returned 404 and are not linked. Poll Management and firebase-1 have repository links only. The private CDAC-ACTS repository is excluded.
